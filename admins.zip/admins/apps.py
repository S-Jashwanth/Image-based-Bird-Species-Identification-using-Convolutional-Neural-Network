from django.apps import AppConfig


class AdminsConfig(AppConfig):
    name = 'admins'
